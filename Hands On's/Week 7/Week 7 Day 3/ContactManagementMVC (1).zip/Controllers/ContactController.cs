using Microsoft.AspNetCore.Mvc;
using ContactManagementMVC.Models;
using System.Collections.Generic;
using System.Linq;

namespace ContactManagementMVC.Controllers
{
    public class ContactController : Controller
    {
        static List<ContactInfo> contacts = new List<ContactInfo>();

        public IActionResult ShowContacts()
        {
            return View(contacts);
        }

        public IActionResult GetContactById(int id)
        {
            var contact = contacts.FirstOrDefault(c => c.ContactId == id);
            return View(contact);
        }

        public IActionResult AddContact()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddContact(ContactInfo contact)
        {
            contacts.Add(contact);
            return RedirectToAction("ShowContacts");
        }
    }
}
